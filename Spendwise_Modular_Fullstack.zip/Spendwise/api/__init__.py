"""Spendwise API package."""
