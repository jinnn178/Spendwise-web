"""Spendwise Telegram integration."""
