"""Spendwise database package."""
